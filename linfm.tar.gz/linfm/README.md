# linfm
Some sort of File Manager, made in the bash interpreter

![Available on Paque](https://media.discordapp.net/attachments/655093392187064360/994649858810052668/InstallOnPaque.png)

Package name: linfm
