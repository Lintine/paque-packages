#!/bin/bash

# Make the file executable
chmod +x $HOME/.paque/packages/linfm/main.sh

# Execute the file
$HOME/.paque/packages/linfm/main.sh
