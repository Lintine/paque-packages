echo '
source $HOME/.paque/packages/classes/classes.sh
' >> ~/.bashrc