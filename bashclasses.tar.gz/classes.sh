#!/bin/bash
# Class module for bash

new() {
    # syntax: new class_name instance_name
    local usage='Usage: new <class_name> <instance_name> [arguments]'
    local __class_name=$1; shift
    local __instance_name=$1; shift

    [ -z $__class_name ] && echo $usage && return 1                                                                                                                                                                                # if the user fails to provide a class name, return an error
    [ -z $__instance_name ] && echo $usage && return 1                                                                                                                                                                             # if the user fails to provide an instance name, return an error

    [[ ! -f "class/$__class_name.sho" ]] && echo "classes: File error:
    Class $__class_name not defined
    Tip: does the file $__class_name.sho exist in \"$PWD/class\"?" && return 2                                                                                                                                                     # if the class is not defined (i.e. "class/$__class_name.sho" does not exist), return an error

    local check=$(bash -n "class/$__class_name.sho")                                                                                                                                                                               # syntax check
    [[ ! -z "$check" ]] && echo "classes: Syntax error:
    $check" && return 3                                                                                                                                                                                                            # if the syntax check failed, return an error.
    . <(sed -e "s/this\./$__instance_name./g;s/\${this/\${$__instance_name/g;s/this\[/$__instance_name\[/g;s/@this=/$__instance_name=/g;s/@this+=/$__instance_name+=/g;s/@this-=/$__instance_name-=/g;" class/$__class_name.sho)   # replace the mentions of "this" with the instance name and execute the replaced code

    local __arg=()                                                                                                                                                                                                                 # load arguments
    while [[ ! -z "$1" ]]; do
        __arg+=("$1"); shift
    done

    eval "$__instance_name.__new ${__arg[@]}"                                                                                                                                                                                      # call constructor
}