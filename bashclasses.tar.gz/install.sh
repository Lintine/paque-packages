echo '
source $HOME/.paque/packages/bashclasses/classes.sh
' >> ~/.bashrc
cat $HOME/.paque/packages/bashclasses/rules.txt | less