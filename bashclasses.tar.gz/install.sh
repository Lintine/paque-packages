echo '
source $HOME/.paque/packages/classes/classes.sh
' >> ~/.bashrc
cat $HOME/.paque/packages/classes/rules.txt | less